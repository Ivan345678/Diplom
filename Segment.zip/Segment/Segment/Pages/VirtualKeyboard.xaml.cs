﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Segment.Pages
{
    /// <summary>
    /// Логика взаимодействия для VirtualKeyboard.xaml
    /// </summary>
    public partial class VirtualKeyboard : UserControl
    {
        public VirtualKeyboard()
        {
            InitializeComponent();
        }
        // Метод для добавления символа в TextBox
        private void AddCharacter(string character)
        {
            if (TextBoxTarget != null)
            {
                TextBoxTarget.Text += character;
                TextBoxTarget.Focus(); // Возвращаем фокус на TextBox
                TextBoxTarget.CaretIndex = TextBoxTarget.Text.Length; // Перемещаем курсор в конец текста
            }
        }

        // Свойство для связывания с TextBox
        public TextBox TextBoxTarget { get; set; }

        // Обработчики нажатия кнопок клавиатуры
        private void KeyButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                AddCharacter(button.Content.ToString());
            }
        }

        // Обработчик для кнопки удаления символа
        private void Backspace_Click(object sender, RoutedEventArgs e)
        {
            if (TextBoxTarget != null && TextBoxTarget.Text.Length > 0)
            {
                TextBoxTarget.Text = TextBoxTarget.Text.Substring(0, TextBoxTarget.Text.Length - 1);
                TextBoxTarget.Focus(); // Возвращаем фокус на TextBox
                TextBoxTarget.CaretIndex = TextBoxTarget.Text.Length; // Перемещаем курсор в конец текста
            }
        }

        private void SpaceButton_Click(object sender, RoutedEventArgs e)
        {
            string button = " ";
            if (button != null)
            {
                AddCharacter(button);
            }
        }
    }
}
