﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Segment.Pages;
using Segment.ServiceData;

namespace Segment.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        
        public MainPage()
        {
            InitializeComponent();
            Update();
            

        }
        private readonly Dictionary<Rectangle, int> rectangleNames = new Dictionary<Rectangle, int>();
        private Dictionary<Shelving, int> shelvingDictionary = new Dictionary<Shelving, int>();
        private Dictionary<ProductInfo, int> productDictionary = new Dictionary<ProductInfo, int>();
        private int Id = 0;
        public static decimal sena;
        public class Shelving
        {
            public int Name { get; set; }
            public double Width { get; set; }
            public double Height { get; set; }
            public double Get_Left { get; set; }
            public double Get_Top { get; set; }
            public int department { get; set; }
            public int shelf { get; set; }
        }
        public class ProductInfo
        {
            public int department { get; set; }
            public int shelf { get; set; }
        }
        private void Update()
        {
            try
            {
                using (var context = new SegmentEntities())
                {
                    // Запрос к базе данных для получения данных
                    var query = context.Стелажи; // Пример запроса, замените на ваш запрос

                    foreach (var data in query)
                    {
                        // Создание элемента Canvas
                        Rectangle rectangle = new Rectangle
                        {
                            Width = Convert.ToDouble(data.Width),
                            Height = Convert.ToDouble(data.Height),
                            Fill = Brushes.Blue,
                            Stroke = Brushes.Black,
                            StrokeThickness = 1
                        };

                        // Генерация уникального имени прямоугольника
                        int shelfId = Convert.ToInt32(data.Id_Полки); // Замените на соответствующее поле из вашей модели
                        int departmentId = data.Id_Отдела; // Замените на соответствующее поле из вашей модели
                        ProductInfo productInfo = new ProductInfo
                        {
                            department = shelfId,
                            shelf = departmentId
                        };
                        Id = Id + 1;
                        int rectangleName = Id;

                        // Добавление прямоугольника и его имени в словарь
                        productDictionary.Add(productInfo, rectangleName);
                        rectangleNames.Add(rectangle, rectangleName);

                        // Установка начальных координат для прямоугольника
                        Canvas.SetLeft(rectangle, Convert.ToDouble(data.Get_Left)); // Предполагаем, что у вас есть свойство Left
                        Canvas.SetTop(rectangle, Convert.ToDouble(data.Get_Top)); // Предполагаем, что у вас есть свойство Top

                        // Добавление прямоугольника на Canvas
                        canvas.Children.Add(rectangle);
                    }
                }
            }
            catch (Exception ex)
            {
                // Обработка исключений при работе с базой данных
                MessageBox.Show("Ошибка при загрузке продуктов: " + ex.Message);
            }
        }

        private void YourTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            VirtualKeyboard keyboard = new VirtualKeyboard();
            keyboard.TextBoxTarget = (TextBox)sender; // Устанавливаем целевой TextBox
            KeyboardPopup.Child = keyboard; // Устанавливаем клавиатуру в качестве содержимого Popup
          
            KeyboardPopup.IsOpen = true; // Открываем Popup
            

        }

        private void KeyboardPopup_LostFocus(object sender, RoutedEventArgs e)
        {
            KeyboardPopup.StaysOpen = false; // Popup будет закрываться при клике вне его
            
        }
        private void YourTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            KeyboardPopup.StaysOpen = true;
        }

        private void SearchBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               
                using (var context = new SegmentEntities())
                {
                    var query = context.Товары; // Пример запроса, замените на ваш запрос
                    foreach (var data in query)
                    {
                        int i1 = data.Id_Отдела;
                        int bar = data.Штрих_код;
                        if(bar == Convert.ToInt32(BarCodTxb.Text))
                        {
                            sena = data.Цена;
                            CheckingPrice keyboard = new CheckingPrice();

                            CheckingPricePopup.Child = keyboard; // Устанавливаем клавиатуру в качестве содержимого Popup

                            CheckingPricePopup.IsOpen = true; // Открываем Popup
                            var timer = new System.Windows.Threading.DispatcherTimer();
                            timer.Interval = TimeSpan.FromSeconds(10);
                            timer.Tick += (s, args) =>
                            {
                               
                                CheckingPricePopup.IsOpen = false; // Открываем Popup


                                timer.Stop();
                            };
                            timer.Start();
                        }
                        string отдел = data.Название;
                        string input = BarCodTxb.Text.ToLower();
                        string[] targetWords = отдел.ToLower().Split(' ');
                        string[] inputWords = input.Split(' ');


                        foreach (string word in inputWords)
                        {
                            if (targetWords.Contains(word))
                            {
                                foreach (var pair in rectangleNames)
                                {
                                    Rectangle rectangle = pair.Key;
                                    int name = pair.Value;
                                    var sd = productDictionary.FirstOrDefault(x => x.Value == pair.Value);
                                    ProductInfo shelving = sd.Key;
                                    int i2 = shelving.department;
                                    if (i1 == i2)
                                    {
                                        rectangle.Fill = Brushes.Black;
                                        rectangle.Width += 10;
                                        rectangle.Height += 10;
                                        var timer = new System.Windows.Threading.DispatcherTimer();
                                        timer.Interval = TimeSpan.FromSeconds(10);
                                        timer.Tick += (s, args) =>
                                        {

                                            // Возвращаем исходный цвет элемента
                                            rectangle.Width -= 10;
                                            rectangle.Height -= 10;
                                            rectangle.Fill = Brushes.Blue;
                                            timer.Stop();
                                        };
                                        timer.Start();
                                    }


                                }
                                
                                return;
                            }
                        }
                    }
                    // Запрос к базе данных для получения данных
                   
                   
                }
            }
            catch (Exception ex)
            {
                // Обработка исключений при работе с базой данных
                MessageBox.Show("Ошибка при загрузке продуктов: " + ex.Message);
            }
        }
        
    }
}

