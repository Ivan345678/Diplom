﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SegmentAdmin.Pages;
using SegmentAdmin.ServiceData;

namespace SegmentAdmin.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        // Словарь для хранения прямоугольников и их уникальных имен
        private readonly Dictionary<Rectangle, string> rectangleNames = new Dictionary<Rectangle, string>();
        // Переменные для отслеживания перетаскивания и изменения размеров прямоугольника
        private Rectangle selectedRectangle;
        private Point startPoint;
        private List<Rectangle> selectedRectangles = new List<Rectangle>();
        private int departmentDepartment;
        private int shelfDepartment;
        private Dictionary<ProductInfo, string> productDictionary = new Dictionary<ProductInfo, string>();
        private Dictionary<Shelving, string> shelvingDictionary = new Dictionary<Shelving, string>();

        public MainPage()
        {
            InitializeComponent();
            LoadShelf();
            LoadDepartment();
            DepartmentComboBox.SelectionChanged += DepartmentComboBox_SelectionChanged;
            ShelfComboBox.SelectionChanged += ShelfComboBox_SelectionChanged;
            Update();

        }

        private void Update()
        {
            try
            {
                using (var context = new SegmentEntities())
                {
                    // Запрос к базе данных для получения данных
                    var query = context.Стелажи; // Пример запроса, замените на ваш запрос

                    foreach (var data in query)
                    {
                        // Создание элемента Canvas
                        Rectangle rectangle = new Rectangle
                        {
                            Width = Convert.ToDouble(data.Width),
                            Height = Convert.ToDouble(data.Height),
                            Fill = Brushes.Blue,
                            Stroke = Brushes.Black,
                            StrokeThickness = 1
                        };

                        // Генерация уникального имени прямоугольника
                        int shelfId = Convert.ToInt32(data.Id_Полки); // Замените на соответствующее поле из вашей модели
                        int departmentId = data.Id_Отдела; // Замените на соответствующее поле из вашей модели
                        ProductInfo productInfo = new ProductInfo
                        {
                            department = departmentId,
                            shelf = shelfId
                        };
                        string rectangleName = $"Rectangle_{DateTime.Now.Ticks}";

                        // Добавление прямоугольника и его имени в словарь
                        productDictionary.Add(productInfo, rectangleName);
                        rectangleNames.Add(rectangle, rectangleName);

                        // Установка начальных координат для прямоугольника
                        Canvas.SetLeft(rectangle, Convert.ToDouble(data.Get_Left)); // Предполагаем, что у вас есть свойство Left
                        Canvas.SetTop(rectangle, Convert.ToDouble(data.Get_Top)); // Предполагаем, что у вас есть свойство Top

                        // Добавление прямоугольника на Canvas
                        canvas.Children.Add(rectangle);
                    }
                }
            }
            catch (Exception ex)
            {
                // Обработка исключений при работе с базой данных
                MessageBox.Show("Ошибка при загрузке продуктов: " + ex.Message);
            }
        }
        private void DepartmentComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Проверка, что выбран элемент
            if (DepartmentComboBox.SelectedItem != null)
            {
                // Запись выбранного значения в переменную
                departmentDepartment = (int)DepartmentComboBox.SelectedValue;
                int selectedTypeId = Convert.ToInt32(DepartmentComboBox.SelectedValue);
                LoadProductsByType(selectedTypeId);
            }
        }
        private void ShelfComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ShelfComboBox.SelectedValue != null)
            {
                shelfDepartment = (int)ShelfComboBox.SelectedValue;
            }
        }

        private void LoadProductsByType(int typeId)
        {
            using (var context = new SegmentEntities())
            {
                // Загрузка продуктов выбранного типа
                var products = context.Полки.Where(p => p.Id_Полки == typeId).ToList();

                // Привязка списка продуктов к второму ComboBox
                ShelfComboBox.ItemsSource = products;
                ShelfComboBox.DisplayMemberPath = "Название"; // Название для отображения
                ShelfComboBox.SelectedValuePath = "Id_Полки"; // Значение
            }
        }
        private void LoadDepartment()
        {
            try
            {
                // Предполагается, что класс DbConnect уже настроен для подключения к базе данных
                using (var context = new SegmentEntities())
                {
                    // Загрузка продуктов из базы данных
                    var products = context.Отделы.ToList();

                    // Привязка списка продуктов к ComboBox
                    DepartmentComboBox.ItemsSource = products;
                    DepartmentComboBox.DisplayMemberPath = "Название"; // Указываем, что отображать в списке
                    DepartmentComboBox.SelectedValuePath = "Id_Отдела"; // Указываем, что использовать в качестве значения
                }
            }
            catch (Exception ex)
            {
                // Обработка исключений при работе с базой данных
                MessageBox.Show("Ошибка при загрузке продуктов: " + ex.Message);
            }
        }
        private void LoadShelf()
        {
            try
            {
                // Предполагается, что класс DbConnect уже настроен для подключения к базе данных
                using (var context = new SegmentEntities())
                {
                    // Загрузка продуктов из базы данных
                    var products = context.Полки.ToList();

                    // Привязка списка продуктов к ComboBox
                    ShelfComboBox.ItemsSource = products;
                    ShelfComboBox.DisplayMemberPath = "Название"; // Указываем, что отображать в списке
                    ShelfComboBox.SelectedValuePath = "Id_Полки"; // Указываем, что использовать в качестве значения
                }
            }
            catch (Exception ex)
            {
                // Обработка исключений при работе с базой данных
                MessageBox.Show("Ошибка при загрузке продуктов: " + ex.Message);
            }
        }


        // Обработчик нажатия на кнопку "Toggle Grid"
        private void ToggleGrid_Click(object sender, RoutedEventArgs e)
        {
            // Переключение видимости сетки
            if (grid.Visibility == Visibility.Visible)
                grid.Visibility = Visibility.Collapsed;
            else
                grid.Visibility = Visibility.Visible;
        }


        public class ProductInfo
        {
            
            public int department { get; set; }
            public int shelf { get; set; }
        }
        public class Shelving
        {
            public string Name { get; set; }
            public double Width { get; set; }
            public double Height { get; set; }
            public double Get_Left { get; set; }
            public double Get_Top { get; set; }
            public int department { get; set; }
            public int shelf { get; set; }
        }
        // Обработчик нажатия на кнопку "Create Rectangle"
        private void CreateRectangle_Click(object sender, RoutedEventArgs e)
        {
            // Создание нового прямоугольника
            if (DepartmentComboBox.SelectedItem != null)
            {
                Rectangle rectangle = new Rectangle
                {
                    Width = 100,
                    Height = 50,
                    Fill = Brushes.Blue,
                    Stroke = Brushes.Black,
                    StrokeThickness = 1
                
                };

                // Генерация уникального имени прямоугольника
                int shelfId = shelfDepartment;
                int departmentId = departmentDepartment;
                ProductInfo productInfo = new ProductInfo
                {
                    department = departmentId,
                    shelf = shelfId
                };
                string rectangleName = $"Rectangle_{DateTime.Now.Ticks}";


                productDictionary.Add(productInfo, rectangleName);


                // Добавление прямоугольника и его имени в словарь
                rectangleNames.Add(rectangle, rectangleName);
                // Установка начальных координат для прямоугольника
                Canvas.SetLeft(rectangle, 100);
                Canvas.SetTop(rectangle, 100);
                // Добавление прямоугольника на Canvas
                canvas.Children.Add(rectangle);
            }
            

            
        }

        private void Canvas_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            var canvas = sender as Canvas;
            Point currentMousePosition = e.GetPosition(canvas);

            double scaleRate = Math.Exp(e.Delta * 0.001);
            ScaleTransform scaleTransform = canvas.LayoutTransform as ScaleTransform ?? new ScaleTransform();

            // Вычисляем новый масштаб
            double newScaleX = scaleTransform.ScaleX * scaleRate;
            double newScaleY = scaleTransform.ScaleY * scaleRate;

            // Применяем новый масштаб
            scaleTransform.ScaleX = newScaleX;
            scaleTransform.ScaleY = newScaleY;

            // Устанавливаем центр масштабирования
            scaleTransform.CenterX = currentMousePosition.X;
            scaleTransform.CenterY = currentMousePosition.Y;

            canvas.LayoutTransform = scaleTransform;

            // Предотвращаем прокрутку страницы
            e.Handled = true;
        }

        private void ScaleCanvas(double scale)
        {
            ScaleTransform st = canvas.LayoutTransform as ScaleTransform;
            if (st == null)
            {
                st = new ScaleTransform(scale, scale);
                canvas.LayoutTransform = st;
            }
            else
            {
                st.ScaleX *= scale;
                st.ScaleY *= scale;
            }
        }

        // Обработчик перемещения мыши по Canvas
        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (selectedRectangle != null && e.LeftButton == MouseButtonState.Pressed && !isResizing)
            {
                Point endPoint = e.GetPosition(canvas);
                double offsetX = endPoint.X - startPoint.X;
                double offsetY = endPoint.Y - startPoint.Y;

                if (Math.Abs(offsetX) > SystemParameters.MinimumHorizontalDragDistance ||
                    Math.Abs(offsetY) > SystemParameters.MinimumVerticalDragDistance)
                {
                    double newLeft = Canvas.GetLeft(selectedRectangle) + offsetX;
                    double newTop = Canvas.GetTop(selectedRectangle) + offsetY;

                    // Ограничение перемещения внутри Canvas
                    newLeft = Math.Max(0, Math.Min(newLeft, canvas.ActualWidth - selectedRectangle.ActualWidth));
                    newTop = Math.Max(0, Math.Min(newTop, canvas.ActualHeight - selectedRectangle.ActualHeight));

                    Canvas.SetLeft(selectedRectangle, newLeft);
                    Canvas.SetTop(selectedRectangle, newTop);

                    startPoint = endPoint;
                }
            }
            else if (selectedRectangle != null && isResizing)
            {
                Point endPoint = e.GetPosition(canvas);
                double offsetX = endPoint.X - startPoint.X;
                double offsetY = endPoint.Y - startPoint.Y;

                double newWidth = selectedRectangle.Width;
                double newHeight = selectedRectangle.Height;
                double newLeft = Canvas.GetLeft(selectedRectangle);
                double newTop = Canvas.GetTop(selectedRectangle);

                switch (resizeDirection)
                {
                    case ResizeDirection.Left:
                        newWidth -= offsetX;
                        newLeft += offsetX;
                        break;
                    case ResizeDirection.Right:
                        newWidth += offsetX;
                        break;
                    case ResizeDirection.Top:
                        newHeight -= offsetY;
                        newTop += offsetY;
                        break;
                    case ResizeDirection.Bottom:
                        newHeight += offsetY;
                        break;
                    case ResizeDirection.TopLeft:
                        newWidth -= offsetX;
                        newHeight -= offsetY;
                        newLeft += offsetX;
                        newTop += offsetY;
                        break;
                    case ResizeDirection.TopRight:
                        newWidth += offsetX;
                        newHeight -= offsetY;
                        newTop += offsetY;
                        break;
                    case ResizeDirection.BottomLeft:
                        newWidth -= offsetX;
                        newHeight += offsetY;
                        newLeft += offsetX;
                        break;
                    case ResizeDirection.BottomRight:
                        newWidth += offsetX;
                        newHeight += offsetY;
                        break;
                }

                if (newWidth > 0 && newHeight > 0)
                {
                    selectedRectangle.Width = newWidth;
                    selectedRectangle.Height = newHeight;
                    Canvas.SetLeft(selectedRectangle, newLeft);
                    Canvas.SetTop(selectedRectangle, newTop);

                    startPoint = endPoint;
                }

            }
        }

        // Обработчик события нажатия мыши на Canvas
        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.Source is Rectangle)
            {
                selectedRectangle = e.Source as Rectangle;
                startPoint = e.GetPosition(canvas);
                selectedRectangle.CaptureMouse();

                // Определение направления изменения размеров прямоугольника
                if (startPoint.X <= Canvas.GetLeft(selectedRectangle) + 3)
                {
                    if (startPoint.Y <= Canvas.GetTop(selectedRectangle) + 3)
                        resizeDirection = ResizeDirection.TopLeft;
                    else if (startPoint.Y >= Canvas.GetTop(selectedRectangle) + selectedRectangle.Height - 3)
                        resizeDirection = ResizeDirection.BottomLeft;
                    else
                        resizeDirection = ResizeDirection.Left;
                }
                else if (startPoint.X >= Canvas.GetLeft(selectedRectangle) + selectedRectangle.Width - 3)
                {
                    if (startPoint.Y <= Canvas.GetTop(selectedRectangle) + 3)
                        resizeDirection = ResizeDirection.TopRight;
                    else if (startPoint.Y >= Canvas.GetTop(selectedRectangle) + selectedRectangle.Height - 3)
                        resizeDirection = ResizeDirection.BottomRight;
                    else
                        resizeDirection = ResizeDirection.Right;
                }
                else if (startPoint.Y <= Canvas.GetTop(selectedRectangle) + 3)
                    resizeDirection = ResizeDirection.Top;
                else if (startPoint.Y >= Canvas.GetTop(selectedRectangle) + selectedRectangle.Height - 3)
                    resizeDirection = ResizeDirection.Bottom;

                if (resizeDirection != ResizeDirection.None)
                    isResizing = true;

                Rectangle clickedRectangle = e.Source as Rectangle;

                // Если нажата клавиша Ctrl, то добавляем или удаляем выделение
                if (Keyboard.Modifiers == ModifierKeys.Control)
                {
                    SelectRectangle(clickedRectangle);
                }
                else // В противном случае выделяем только этот элемент
                {
                    foreach (Rectangle rectangle in selectedRectangles)
                    {
                        rectangle.Stroke = Brushes.Black; // Возвращаем обычный цвет всем выделенным элементам
                    }
                    selectedRectangles.Clear();
                    SelectRectangle(clickedRectangle);
                }
            }
        }

        // Обработчик отпускания кнопки мыши на Canvas
        private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (selectedRectangle != null)
            {
                selectedRectangle.ReleaseMouseCapture();
                selectedRectangle = null;
                isResizing = false;
                resizeDirection = ResizeDirection.None;
            }
        }

        // Обработчик нажатия на кнопку "Show Rectangles Info"
        private void ShowRectanglesInfo_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Список для хранения информации о прямоугольниках
                List<string> rectangleInfo = new List<string>();
                // Перебор всех прямоугольников в словаре
                foreach (var pair in rectangleNames)
                {


                    Rectangle rectangle = pair.Key;
                    string name = pair.Value;
                    double left = Canvas.GetLeft(rectangle);
                    double top = Canvas.GetTop(rectangle);
                    double width = rectangle.Width;
                    double height = rectangle.Height;

                    Shelving shelving = new Shelving
                    {
                        Name = name,
                        Width = width,
                        Height = height,
                        Get_Left = left,
                        Get_Top = top,
                    };
                    rectangleInfo.Add($"{name}: Left={left}, Top={top}, Width={width}, Height={height}");
                    shelvingDictionary.Add(shelving, pair.Value);
                    MessageBox.Show(string.Join("\n", rectangleInfo), "Rectangles Information");

                }
                foreach (var pair in productDictionary)
                {
                    var i = pair.Key;
                    ProductInfo productInfo = pair.Key;
                    
                    {

                        string name = pair.Value;
                        int department = productInfo.department;
                        int shelf = productInfo.shelf;
                        var s = shelvingDictionary.FirstOrDefault(x => x.Value == pair.Value);
                        Shelving shelving = s.Key;
                        shelving.department = department;
                        shelving.shelf = shelf;
                        rectangleInfo.Add($"{name}: Left={department}, Top={shelf}");
                    }




                    MessageBox.Show(string.Join("\n", rectangleInfo), "Rectangles Information");



                }
                using (var context = new SegmentEntities())
                {
                    context.Database.ExecuteSqlCommand("TRUNCATE TABLE [Стелажи]");
                    context.SaveChanges();
                }

                foreach (var pair in shelvingDictionary)
                {
                    Shelving shelving = pair.Key;
                    if (shelving.department != 0)
                    {

                        string name = pair.Value;
                        int department = shelving.department;
                        int shelf = shelving.shelf;
                        double left = shelving.Get_Left;
                        double top = shelving.Get_Top;
                        double width = shelving.Width;
                        double height = shelving.Height;

                        Стелажи newстилажи = new Стелажи
                        {
                            Get_Left = shelving.Get_Left,
                            Get_Top = shelving.Get_Top,
                            Width = shelving.Width,
                            Height = shelving.Height,
                            Id_Отдела = shelving.department,
                            Id_Полки = shelving.shelf
                        };

                        rectangleInfo.Add($"{name}: department={department}, shelf={shelf}, Left={left}, Top={top}, Width={width}, Height={height}");
                        MessageBox.Show(string.Join("\n", rectangleInfo), "Rectangles Information");
                        DbConnect.entObj.Стелажи.Add(newстилажи);
                        DbConnect.entObj.SaveChanges();
                    }
                   

                    // Отображение информации о прямоугольниках в MessageBox
                    MessageBox.Show(string.Join("\n", rectangleInfo), "Rectangles Information");
                }
            }
            catch { MessageBox.Show("нет"); }
        }
        private bool isResizing = false;
        private ResizeDirection resizeDirection;

        // Перечисление для определения направления изменения размеров прямоугольника
        private enum ResizeDirection
        {
            None,
            Left,
            Right,
            Top,
            Bottom,
            TopLeft,
            TopRight,
            BottomLeft,
            BottomRight
        }

        private void SelectRectangle(Rectangle rectangle)
        {
            if (!selectedRectangles.Contains(rectangle))
            {
                rectangle.Stroke = Brushes.Red; // Выделение красным цветом
                selectedRectangles.Add(rectangle);
            }
            else
            {
                rectangle.Stroke = Brushes.Black; // Возврат обычного цвета
                selectedRectangles.Remove(rectangle);
            }
        }

        private void DeleteSelected_Click(object sender, RoutedEventArgs e)
        {
            foreach (Rectangle rectangle in selectedRectangles)
            {
                // Получение значений свойств
                double width = rectangle.Width;
                double height = rectangle.Height;
                double left = Canvas.GetLeft(rectangle);
                double top = Canvas.GetTop(rectangle);

                // Вывод значений свойств
                Console.WriteLine($"Rectangle: Width={width}, Height={height}, Left={left}, Top={top}");

                canvas.Children.Remove(rectangle);
                rectangleNames.Remove(rectangle);
            }
        }

        private void ExitBtn_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new LoginPage());
        }
    }
}
